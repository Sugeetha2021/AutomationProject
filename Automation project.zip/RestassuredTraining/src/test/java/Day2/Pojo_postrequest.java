package Day2;

public class Pojo_postrequest {
String name;
String location;
String courses[];
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String[] getCourses() {
	return courses;
}
public void setCourses(String[] courses) {
	this.courses = courses;
}

}
